/* have structure linger */
#undef HAVE_STRUCT_LINGER

/* dump debugging output to logs */
#undef DEBUG

/* does compiler support __atribute__((packed)) */
#undef HAVE_ATTRIB_PACKED

/* #pragma for compiler to not align structure members */
#undef HAVE_PRAGMA_PACK

/* use memwatch for debugging */
#undef MEMWATCH

/* Name of this package.  */
#undef PACKAGE

/* Version of this package.  */
#undef VERSION

